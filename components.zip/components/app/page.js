"use client";

import { useState, useRef, useEffect } from "react";
import styles from "./page.module.css";
import { useRouter } from "next/navigation";
import axiosInstance, { verifyToken } from "@/lib/axios";

export default function AdminLogin() {
  const [step, setStep] = useState("mobile");
  const [mobileNumber, setMobileNumber] = useState("");
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [checkingAuth, setCheckingAuth] = useState(true);
  const otpRefs = useRef([]);
  const router = useRouter();

  // 2FA state
  const [totpCode, setTotpCode] = useState("");
  const [pending2faToken, setPending2faToken] = useState("");
  const [qrCode, setQrCode] = useState("");
  const [manualKey, setManualKey] = useState("");
  const [backupCodes, setBackupCodes] = useState([]);

  // Check authentication on mount
  useEffect(() => {
    const checkAuthentication = async () => {
      try {
        const userData = localStorage.getItem("user");
        if (!userData) {
          setCheckingAuth(false);
          return;
        }

        const user = JSON.parse(userData);

        if (user.role !== "admin") {
          localStorage.removeItem("user");
          setCheckingAuth(false);
          return;
        }

        const verifyResponse = await verifyToken();

        if (verifyResponse && verifyResponse.status === 200) {
          // Check if 2FA setup is needed
          if (verifyResponse.data?.data?.totp_enabled === false) {
            setStep("2fa-setup-init");
            setCheckingAuth(false);
            return;
          }
          if (user.role === "admin") {
            router.push("/portal/admin/home");
          } else if (user.role === "support") {
            router.push("/portal/support/fittbotbusiness");
          } else if (user.role === "nutritionist") {
            router.push("/portal/nutritionist/home");
          }
        } else {
          localStorage.removeItem("user");
          setCheckingAuth(false);
        }
      } catch (error) {
        localStorage.removeItem("user");
        setCheckingAuth(false);
      }
    };

    checkAuthentication();
  }, [router]);

  useEffect(() => {
    if (step === "otp" || step === "forgot-otp") {
      setTimeout(() => {
        otpRefs.current[0]?.focus();
      }, 100);
    }
  }, [step]);

  // Navigate to dashboard based on role
  const navigateToDashboard = (role) => {
    if (role === "admin") {
      router.push("/portal/admin/home");
    } else if (role === "support") {
      router.push("/portal/support/fittbotbusiness");
    } else if (role === "nutritionist") {
      router.push("/portal/nutritionist/home");
    }
  };

  // Handle mobile number + password submission
  const handleMobileSubmit = async (e) => {
    e.preventDefault();
    if (mobileNumber.length >= 10) {
      setLoading(true);
      setError("");

      try {
        const response = await axiosInstance.post("/api/admin/auth/login", {
          mobile_number: mobileNumber,
          password: password,
        });

        if (response.data.status === 200) {
          // 2FA is enabled — need to verify TOTP code
          if (response.data.requires_2fa) {
            setPending2faToken(response.data.pending_2fa_token);
            setTotpCode("");
            setStep("2fa-verify");
            return;
          }

          // Login successful — store user data
          localStorage.setItem("user", JSON.stringify(response.data.data));

          // 2FA not set up yet — force setup
          if (response.data.requires_2fa_setup) {
            setStep("2fa-setup-init");
            return;
          }

          // All good — go to dashboard
          const role = response.data.data.role;
          if (["admin", "support", "nutritionist"].includes(role)) {
            navigateToDashboard(role);
          } else {
            setError("Only admins are allowed to access this portal");
            localStorage.removeItem("user");
            handleBack();
          }
        } else {
          setError(response?.data?.detail || "Failed to Login");
        }
      } catch (err) {
        if (err.response?.status === 400) {
          setError("Only admins are allowed to access this portal");
        } else {
          setError(
            err.response?.data?.detail || "Failed to Login. Please try again."
          );
        }
      } finally {
        setLoading(false);
      }
    }
  };

  // ========== 2FA SETUP FLOW ==========

  // Step 1: Call /2fa/setup to get QR code
  const handle2FASetupInit = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await axiosInstance.post("/api/admin/auth/2fa/setup");

      if (response.data.status === 200) {
        setQrCode(response.data.data.qr_code);
        setManualKey(response.data.data.manual_entry_key);
        setStep("2fa-setup-scan");
      } else {
        setError(response?.data?.detail || "Failed to start 2FA setup");
      }
    } catch (err) {
      setError(
        err.response?.data?.detail || "Failed to start 2FA setup. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Verify the first TOTP code to confirm setup
  const handle2FASetupVerify = async (e) => {
    e.preventDefault();
    if (totpCode.length !== 6) return;

    setLoading(true);
    setError("");

    try {
      const response = await axiosInstance.post("/api/admin/auth/2fa/verify-setup", {
        totp_code: totpCode,
      });

      if (response.data.status === 200) {
        setBackupCodes(response.data.data.backup_codes);
        // Update localStorage with totp_enabled
        const userData = localStorage.getItem("user");
        if (userData) {
          const user = JSON.parse(userData);
          user.totp_enabled = true;
          localStorage.setItem("user", JSON.stringify(user));
        }
        setStep("2fa-backup-codes");
      } else {
        setError(response?.data?.detail || "Invalid code. Please try again.");
      }
    } catch (err) {
      setError(
        err.response?.data?.detail || "Invalid code. Please try again."
      );
    } finally {
      setLoading(false);
      setTotpCode("");
    }
  };

  // Step 3: After backup codes shown, go to dashboard
  const handle2FASetupComplete = () => {
    const userData = localStorage.getItem("user");
    if (userData) {
      const user = JSON.parse(userData);
      navigateToDashboard(user.role);
    }
  };

  // ========== 2FA LOGIN VERIFY ==========

  const handle2FAVerify = async (e) => {
    e.preventDefault();
    if (totpCode.length < 6) return;

    setLoading(true);
    setError("");

    try {
      const response = await axiosInstance.post("/api/admin/auth/2fa/verify", {
        pending_2fa_token: pending2faToken,
        totp_code: totpCode,
      });

      if (response.data.status === 200) {
        localStorage.setItem("user", JSON.stringify(response.data.data));
        const role = response.data.data.role;
        navigateToDashboard(role);
      } else {
        setError(response?.data?.detail || "Invalid 2FA code");
      }
    } catch (err) {
      if (err.response?.status === 429) {
        setError("Too many attempts. Please try again in 15 minutes.");
      } else {
        setError(
          err.response?.data?.detail || "Invalid 2FA code. Please try again."
        );
      }
    } finally {
      setLoading(false);
      setTotpCode("");
    }
  };

  // ========== EXISTING HANDLERS ==========

  const handleOtpChange = (index, value) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
    if (e.key === "Enter") {
      handleOtpSubmit(e);
    }
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    const otpValue = otp.join("");
    if (otpValue.length === 6) {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post("/api/admin/auth/verify_otp", {
          mobile_number: mobileNumber,
          otp: otpValue,
          device: "web",
          role: "admin",
        });
        if (response.data.status === 200) {
          setStep("set-password");
          setOtp(["", "", "", "", "", ""]);
        } else {
          setError(response.data.message || "Incorrect OTP");
        }
      } catch (err) {
        if (err.response?.status === 403) {
          setError("Only admins are allowed to access this portal");
        } else {
          setError(err.response?.data?.detail || "Incorrect OTP. Please try again.");
        }
      } finally {
        setLoading(false);
      }
    }
  };

  const handleSetPasswordSubmit = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const response = await axiosInstance.post("/api/admin/auth/change_password", {
        mobile_number: mobileNumber,
        new_password: newPassword,
      });
      if (response.data.status === 200) {
        setStep("mobile");
      } else {
        setError(response?.data?.detail || "Failed to set password");
      }
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to set password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setStep("mobile");
    setOtp(["", "", "", "", "", ""]);
    setTotpCode("");
    setPending2faToken("");
    setError("");
  };

  const handleResendOtp = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await axiosInstance.post("/api/admin/auth/resend-otp", {
        data: mobileNumber,
      });
      if (response.data.status === 200) {
        setOtp(["", "", "", "", "", ""]);
        setError("OTP sent successfully!");
        setTimeout(() => setError(""), 3000);
      } else {
        setError(response.data.message || "Failed to resend OTP");
      }
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to resend OTP");
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPasswordMobile = async (e) => {
    e.preventDefault();
    if (mobileNumber.length >= 10) {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post("/api/admin/auth/send_otp", {
          mobile_number: mobileNumber,
        });
        if (response.data.status === 200) {
          setStep("forgot-otp");
        } else {
          setError(response?.data?.detail || "Failed to send OTP");
        }
      } catch (err) {
        setError(err.response?.data?.detail || "Failed to send OTP. Please try again.");
      } finally {
        setLoading(false);
      }
    }
  };

  const handleForgotPasswordOtp = async (e) => {
    e.preventDefault();
    const otpValue = otp.join("");
    if (otpValue.length === 6) {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post("/api/admin/auth/verify_otp", {
          mobile_number: mobileNumber,
          otp: otpValue,
          device: "web",
          role: "admin",
        });
        if (response.data.status === 200) {
          setStep("forgot-password");
          setOtp(["", "", "", "", "", ""]);
        } else {
          setError(response.data.message || "Incorrect OTP");
        }
      } catch (err) {
        if (err.response?.status === 403) {
          setError("Only admins are allowed to access this portal");
        } else {
          setError(err.response?.data?.detail || "Incorrect OTP. Please try again.");
        }
      } finally {
        setLoading(false);
      }
    }
  };

  const handleNewPasswordSubmit = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const response = await axiosInstance.post("/api/admin/auth/change_password", {
        mobile_number: mobileNumber,
        new_password: newPassword,
      });
      if (response.data.status === 200) {
        setError("Password changed successfully! Please login with your new password.");
        setTimeout(() => {
          handleCancelForgotPassword();
        }, 2000);
      } else {
        setError(response?.data?.detail || "Failed to reset password");
      }
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to reset password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCancelForgotPassword = () => {
    setStep("mobile");
    setMobileNumber("");
    setNewPassword("");
    setConfirmPassword("");
    setOtp(["", "", "", "", "", ""]);
    setError("");
  };

  // Show loading while checking authentication
  if (checkingAuth) {
    return (
      <div className={styles.loginContainer}>
        <div className={styles.loginCard}>
          <div className={styles.brandContainer}>
            <h1 className={styles.brandName}>
              <span className={styles.fitt}>Fy</span>
              <span className={styles.bot}>mble</span>
            </h1>
            <p className={styles.subtitle}>Admin Dashboard</p>
          </div>
          <div style={{ display: "flex", justifyContent: "center", padding: "2rem" }}>
            <div className={styles.loader}></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.loginContainer}>
      <div className={styles.loginCard}>
        {/* Brand Logo */}
        <div className={styles.brandContainer}>
          <h1 className={styles.brandName}>
            <span className={styles.fitt}>Fy</span>
            <span className={styles.bot}>mble</span>
          </h1>
          <p className={styles.subtitle}>Admin Dashboard</p>
        </div>

        {/* Mobile Number + Password Step */}
        {step === "mobile" && (
          <form onSubmit={handleMobileSubmit} className={styles.form}>
            <div className={styles.inputGroup}>
              <label htmlFor="mobile" className={styles.label}>Mobile Number</label>
              <div className={styles.phoneInputContainer}>
                <span className={styles.countryCode}>+91</span>
                <input
                  id="mobile"
                  type="tel"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  placeholder="Enter your mobile number"
                  className={styles.phoneInput}
                  maxLength="10"
                  required
                />
              </div>
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="password" className={styles.label}>Password</label>
              <div className={styles.phoneInputContainer}>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your Password"
                  className={styles.phoneInput}
                  required
                />
              </div>
            </div>

            {error && <div className={styles.errorMessage}>{error}</div>}

            <button
              type="submit"
              className={styles.submitButton}
              disabled={mobileNumber.length < 10 || !password || loading}
            >
              {loading ? <div className={styles.loader}></div> : "Login"}
            </button>

            <button
              type="button"
              onClick={() => setStep("forgot-mobile")}
              className={styles.forgotPasswordButton}
              disabled={loading}
            >
              Forgot Password
            </button>
          </form>
        )}

        {/* ========== 2FA VERIFY (Login with 2FA enabled) ========== */}
        {step === "2fa-verify" && (
          <div className={styles.otpContainer}>
            <button onClick={handleBack} className={styles.backButton}>
              &larr; Back
            </button>

            <div className={styles.otpHeader}>
              <div className={styles.tfaIcon}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ff5757" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
              </div>
              <h2 className={styles.otpTitle}>Two-Factor Authentication</h2>
              <p className={styles.otpSubtitle}>
                Enter the 6-digit code from your authenticator app
              </p>
            </div>

            <form onSubmit={handle2FAVerify} className={styles.form}>
              <div className={styles.inputGroup}>
                <div className={styles.phoneInputContainer}>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={totpCode}
                    onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, "").slice(0, 8))}
                    placeholder="Enter 2FA code"
                    className={styles.phoneInput}
                    style={{ textAlign: "center", letterSpacing: "0.3em", fontSize: "1.2rem" }}
                    autoFocus
                    autoComplete="off"
                  />
                </div>
              </div>

              <p style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.8rem", textAlign: "center", margin: 0 }}>
                You can also use a backup code
              </p>

              {error && <div className={styles.errorMessage}>{error}</div>}

              <button
                type="submit"
                className={styles.submitButton}
                disabled={totpCode.length < 6 || loading}
              >
                {loading ? <div className={styles.loader}></div> : "Verify"}
              </button>
            </form>
          </div>
        )}

        {/* ========== 2FA SETUP INIT (Mandatory setup before first use) ========== */}
        {step === "2fa-setup-init" && (
          <div className={styles.otpContainer}>
            <div className={styles.otpHeader}>
              <div className={styles.tfaIcon}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ff5757" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
              </div>
              <h2 className={styles.otpTitle}>Set Up 2FA</h2>
              <p className={styles.otpSubtitle}>
                Two-factor authentication is required for all admin accounts. Set it up to continue.
              </p>
            </div>

            {error && <div className={styles.errorMessage}>{error}</div>}

            <button
              className={styles.submitButton}
              onClick={handle2FASetupInit}
              disabled={loading}
            >
              {loading ? <div className={styles.loader}></div> : "Get Started"}
            </button>

            <p style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.8rem", textAlign: "center", margin: 0, lineHeight: 1.5 }}>
              You will need Google Authenticator or Authy app on your phone
            </p>
          </div>
        )}

        {/* ========== 2FA SETUP SCAN (Show QR code) ========== */}
        {step === "2fa-setup-scan" && (
          <div className={styles.otpContainer}>
            <div className={styles.otpHeader}>
              <h2 className={styles.otpTitle}>Scan QR Code</h2>
              <p className={styles.otpSubtitle}>
                Open your authenticator app and scan this QR code
              </p>
            </div>

            {qrCode && (
              <div className={styles.qrContainer}>
                <img
                  src={`data:image/png;base64,${qrCode}`}
                  alt="2FA QR Code"
                  className={styles.qrImage}
                />
              </div>
            )}

            <div className={styles.manualKeyContainer}>
              <p style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.8rem", margin: "0 0 6px 0", textAlign: "center" }}>
                Or enter this key manually:
              </p>
              <div
                className={styles.manualKey}
                onClick={() => {
                  navigator.clipboard.writeText(manualKey);
                  setError("Key copied to clipboard!");
                  setTimeout(() => setError(""), 2000);
                }}
              >
                {manualKey}
              </div>
            </div>

            {error && (
              <div className={error.includes("copied") ? styles.successMessage : styles.errorMessage}>
                {error}
              </div>
            )}

            <form onSubmit={handle2FASetupVerify} className={styles.form}>
              <div className={styles.inputGroup}>
                <label className={styles.label}>Enter the 6-digit code from your app</label>
                <div className={styles.phoneInputContainer}>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={totpCode}
                    onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    placeholder="000000"
                    className={styles.phoneInput}
                    style={{ textAlign: "center", letterSpacing: "0.3em", fontSize: "1.2rem" }}
                    autoComplete="off"
                  />
                </div>
              </div>

              <button
                type="submit"
                className={styles.submitButton}
                disabled={totpCode.length !== 6 || loading}
              >
                {loading ? <div className={styles.loader}></div> : "Verify & Activate"}
              </button>
            </form>
          </div>
        )}

        {/* ========== 2FA BACKUP CODES (Show once after setup) ========== */}
        {step === "2fa-backup-codes" && (
          <div className={styles.otpContainer}>
            <div className={styles.otpHeader}>
              <div className={styles.tfaIcon}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                  <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
              </div>
              <h2 className={styles.otpTitle}>2FA Enabled!</h2>
              <p className={styles.otpSubtitle}>
                Save these backup codes somewhere safe. Each code can only be used once.
              </p>
            </div>

            <div className={styles.backupCodesGrid}>
              {backupCodes.map((code, index) => (
                <div key={index} className={styles.backupCode}>
                  {code}
                </div>
              ))}
            </div>

            <button
              className={styles.forgotPasswordButton}
              onClick={() => {
                navigator.clipboard.writeText(backupCodes.join("\n"));
                setError("Backup codes copied to clipboard!");
                setTimeout(() => setError(""), 2000);
              }}
            >
              Copy All Codes
            </button>

            {error && (
              <div className={error.includes("copied") ? styles.successMessage : styles.errorMessage}>
                {error}
              </div>
            )}

            <button
              className={styles.submitButton}
              onClick={handle2FASetupComplete}
            >
              I&apos;ve Saved My Codes — Continue
            </button>
          </div>
        )}

        {/* OTP Step */}
        {step === "otp" && (
          <div className={styles.otpContainer}>
            <button onClick={handleBack} className={styles.backButton}>
              &larr; Back
            </button>

            <div className={styles.otpHeader}>
              <h2 className={styles.otpTitle}>Enter OTP</h2>
              <p className={styles.otpSubtitle}>
                We&rsquo;ve sent a 6-digit code to +91 {mobileNumber}
              </p>
            </div>

            <form onSubmit={handleOtpSubmit} className={styles.form}>
              <div className={styles.otpInputContainer}>
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => (otpRefs.current[index] = el)}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]"
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                    className={styles.otpInput}
                    maxLength="1"
                    autoComplete="off"
                  />
                ))}
              </div>

              {error && (
                <div className={error.includes("successfully") ? styles.successMessage : styles.errorMessage}>
                  {error}
                </div>
              )}

              <button
                type="submit"
                className={styles.submitButton}
                disabled={otp.join("").length < 6 || loading}
              >
                {loading ? <div className={styles.loader}></div> : "Verify OTP"}
              </button>
            </form>

            <button
              type="button"
              onClick={handleResendOtp}
              className={styles.resendButton}
              disabled={loading}
            >
              Didn&rsquo;t receive code? Resend
            </button>
          </div>
        )}

        {/* Set Password Step (After OTP Verification) */}
        {step === "set-password" && (
          <div>
            <button onClick={handleBack} className={styles.backButton}>
              &larr; Back
            </button>

            <div className={styles.otpHeader}>
              <h2 className={styles.otpTitle}>Set Your Password</h2>
              <p className={styles.otpSubtitle}>Create a password for your account</p>
            </div>

            <form onSubmit={handleSetPasswordSubmit} className={styles.form}>
              <div className={styles.inputGroup}>
                <label htmlFor="set-password" className={styles.label}>Password</label>
                <div className={styles.phoneInputContainer}>
                  <input
                    id="set-password"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter your password"
                    className={styles.phoneInput}
                    required
                  />
                </div>
              </div>

              <div className={styles.inputGroup}>
                <label htmlFor="set-confirm-password" className={styles.label}>Confirm Password</label>
                <div className={styles.phoneInputContainer}>
                  <input
                    id="set-confirm-password"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm your password"
                    className={styles.phoneInput}
                    required
                  />
                </div>
              </div>

              {error && <div className={styles.errorMessage}>{error}</div>}

              <button
                type="submit"
                className={styles.submitButton}
                disabled={!newPassword || !confirmPassword || loading}
              >
                {loading ? <div className={styles.loader}></div> : "Set Password"}
              </button>
            </form>
          </div>
        )}

        {/* Forgot Password - Mobile Number Step */}
        {step === "forgot-mobile" && (
          <div>
            <button onClick={handleCancelForgotPassword} className={styles.backButton}>
              &larr; Back
            </button>

            <div className={styles.otpHeader} style={{ paddingTop: "1rem", paddingBottom: "1.5rem" }}>
              <h3 className={styles.otpTitle} style={{ color: "#FF5757" }}>Forgot Password</h3>
            </div>

            <form onSubmit={handleForgotPasswordMobile} className={styles.form}>
              <div className={styles.inputGroup} style={{ paddingBottom: "1rem" }}>
                <label htmlFor="forgot-mobile" className={styles.label} style={{ paddingBottom: "0.5rem" }}>
                  Mobile Number
                </label>
                <div className={styles.phoneInputContainer}>
                  <span className={styles.countryCode}>+91</span>
                  <input
                    id="forgot-mobile"
                    type="tel"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    placeholder="Enter your mobile number"
                    className={styles.phoneInput}
                    maxLength="10"
                    required
                  />
                </div>
              </div>

              {error && (
                <div className={styles.errorMessage} style={{ paddingBottom: "1rem" }}>
                  {error}
                </div>
              )}

              <button
                type="submit"
                className={styles.submitButton}
                disabled={mobileNumber.length < 10 || loading}
                style={{ marginTop: "1rem" }}
              >
                {loading ? <div className={styles.loader}></div> : "Send OTP"}
              </button>
            </form>
          </div>
        )}

        {/* Forgot Password - OTP Step */}
        {step === "forgot-otp" && (
          <div className={styles.otpContainer}>
            <button onClick={handleCancelForgotPassword} className={styles.backButton}>
              &larr; Back
            </button>

            <div className={styles.otpHeader}>
              <h2 className={styles.otpTitle}>Enter OTP</h2>
              <p className={styles.otpSubtitle}>
                We&rsquo;ve sent a 6-digit code to +91 {mobileNumber}
              </p>
            </div>

            <form onSubmit={handleForgotPasswordOtp} className={styles.form}>
              <div className={styles.otpInputContainer}>
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => (otpRefs.current[index] = el)}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]"
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                    className={styles.otpInput}
                    maxLength="1"
                    autoComplete="off"
                  />
                ))}
              </div>

              {error && (
                <div className={error.includes("successfully") ? styles.successMessage : styles.errorMessage}>
                  {error}
                </div>
              )}

              <button
                type="submit"
                className={styles.submitButton}
                disabled={otp.join("").length < 6 || loading}
              >
                {loading ? <div className={styles.loader}></div> : "Verify OTP"}
              </button>
            </form>

            <button
              type="button"
              onClick={handleResendOtp}
              className={styles.resendButton}
              disabled={loading}
            >
              Didn&rsquo;t receive code? Resend
            </button>
          </div>
        )}

        {/* Forgot Password - New Password Step */}
        {step === "forgot-password" && (
          <div>
            <button onClick={handleCancelForgotPassword} className={styles.backButton}>
              &larr; Back
            </button>

            <div className={styles.otpHeader}>
              <h2 className={styles.otpTitle}>Set New Password</h2>
            </div>

            <form onSubmit={handleNewPasswordSubmit} className={styles.form}>
              <div className={styles.inputGroup}>
                <label htmlFor="new-password" className={styles.label}>New Password</label>
                <div className={styles.phoneInputContainer}>
                  <input
                    id="new-password"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className={styles.phoneInput}
                    required
                  />
                </div>
              </div>

              <div className={styles.inputGroup}>
                <label htmlFor="confirm-password" className={styles.label}>Confirm Password</label>
                <div className={styles.phoneInputContainer}>
                  <input
                    id="confirm-password"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm new password"
                    className={styles.phoneInput}
                    required
                  />
                </div>
              </div>

              {error && <div className={styles.errorMessage}>{error}</div>}

              <button
                type="submit"
                className={styles.submitButton}
                disabled={!newPassword || !confirmPassword || loading}
              >
                {loading ? <div className={styles.loader}></div> : "Reset Password & Login"}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
